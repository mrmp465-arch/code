﻿using Card.Data.DTO;
using Card.Data.Service;
using Card.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Card.CMS.Filter;
using Card.CMS.Models;
using Card.Data.Api;
using System.Configuration;

namespace Card.CMS.Controllers
{
    public class HomeController : Controller
    {
        private readonly IUsersService _userservice;
        private readonly IAccountTokenService _accounttokenservice;
        private readonly IUsersLogService _userlogservice;
        private readonly IFucntionsService _functionservice;
        private readonly IUserRoleService _userroleservice;
        private readonly IOrderTempsService _oservice;
        private readonly IOrderReportsService _orderservice;
        private readonly ITransactionsService _transervice;
        private readonly IBidHistoryService _bidHistoryservice;
        private UserSession CurrentUser { get { return ((UserSession)Session[SessionsManager.SESSION_USER]); } }
        private Users CurrentFullUser { get { return ((Users)Session[SessionsManager.SESSION_USER_FULL]); } set { } }
        public HomeController(IBidHistoryService bidHistoryservice, IOrderReportsService orderservice, IOrderTempsService oservice, IAccountTokenService accounttokenservice, IUsersService userservice, IUsersLogService userlogservice, IFucntionsService functionservice, IUserRoleService userroleservice, ITransactionsService transervice)
        {
            _userservice = userservice;
            _userlogservice = userlogservice;
            _userroleservice = userroleservice;
            _functionservice = functionservice;
            _transervice = transervice;
            _accounttokenservice = accounttokenservice;
            _oservice = oservice;
            _orderservice = orderservice;
            _bidHistoryservice = bidHistoryservice;
        }
        public ActionResult Index()
        {

            if (CurrentUser == null)
                return RedirectToAction("Login", "Account");
            var user = _userservice.GetByUsername(CurrentUser.Username);
            ViewBag.Order = user.StatusOrder;
            Session[SessionsManager.SESSION_USER_FULL] = user;
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                user.StatusVMS = user.StatusVMS && parrent.StatusVMS;
                user.StatusVTT = user.StatusVTT && parrent.StatusVTT;
                user.StatusVNP = user.StatusVNP && parrent.StatusVNP;
                user.StatusZing = user.StatusZing && parrent.StatusZing;
                user.StatusGarena = user.StatusGarena && parrent.StatusGarena;
                user.StatusVTC = user.StatusVTC && parrent.StatusVTC;
            }
            if (!user.StatusVMS && !user.StatusVTT && !user.StatusVNP)

                return View("Game", user);

            return View(user);
        }
        public ActionResult Game()
        {

            if (CurrentUser == null)
                return RedirectToAction("Login", "Account");
            var user = _userservice.GetByUsername(CurrentUser.Username);
            ViewBag.Order = user.StatusOrder;
            Session[SessionsManager.SESSION_USER_FULL] = user;
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                user.StatusVMS = user.StatusVMS && parrent.StatusVMS;
                user.StatusVTT = user.StatusVTT && parrent.StatusVTT;
                user.StatusVNP = user.StatusVNP && parrent.StatusVNP;
                user.StatusZing = user.StatusZing && parrent.StatusZing;
                user.StatusGarena = user.StatusGarena && parrent.StatusGarena;
                user.StatusGarena = user.StatusVTC && parrent.StatusVTC;
            }
            return View(user);
        }
        [PermissionFilter(FunctionCode = FunctionCode.OrderVNP)]
        public ActionResult OrderVNP()
        {

            if (CurrentUser == null)
                return RedirectToAction("Login", "Account");

            var user = _userservice.GetByUsername(CurrentUser.Username);
            if (!user.StatusVNP)
            {
                return RedirectToAction("Index", "Home");
            }
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                if (!parrent.StatusVNP)
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            ViewBag.MKBH = "";
            if (Session["MKBH"] != null)
            {
                ViewBag.MKBH = Session["MKBH"].ToString();
            }
            ViewBag.Order = user.StatusOrder;
            Session[SessionsManager.SESSION_USER_FULL] = user;
            return View(user);
        }
        //[ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult OrderVNP(List<OrderModel> lstorder)
        {
            var ReturnData = new ReturnData();
            try
            {
                if (CurrentFullUser == null)
                {

                    ReturnData.ResponseCode = -101;
                    ReturnData.Description = "Bạn không có quyền sử dụng chức năng này";
                    return Json(ReturnData);

                }
                var password = Encrypt.MD5(lstorder[0].Password2.Trim() + Config.GetAppsetting("Salt"));
                if (CurrentFullUser.Password2 != password)
                {
                    ReturnData.ResponseCode = -104;
                    ReturnData.Description = "Mật khẩu bán hàng không chính xác";
                    return Json(ReturnData);
                }
                var parrentUser = _userservice.GetByUsername(CurrentFullUser.CreatedUser);
                var C1User = parrentUser;
                if (CurrentFullUser.Type == 5)
                    C1User = _userservice.GetByUsername(parrentUser.CreatedUser);

                Session["MKBH"] = lstorder[0].Password2.Trim();
                var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                if (string.IsNullOrEmpty(token))
                {
                    token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                    Session[SessionsManager.SESSION_TOKEN] = token;
                }
                var pecent = CurrentFullUser.PercentVNP;
                int totalAmount = lstorder.Sum(x => x.Amount) / 100;
                int total = (totalAmount * pecent);
                if (CurrentFullUser.Balance < total)
                {
                    ReturnData.ResponseCode = -105;
                    ReturnData.Description = "Số dư không đủ để tạo đơn hàng";
                    return Json(ReturnData);
                }

                var orderNo = lstorder[0].OrderNo;
                if (!string.IsNullOrEmpty(orderNo))
                {
                    if (!orderNo.StartsWith("RT_"))
                        orderNo = StringUtils.FormatOrderNo(orderNo);
                }
                var totalAmountSucces = 0;
                var lstOrderData = new List<OrderInput>();
                foreach (var order in lstorder)
                {
                    pecent = CurrentFullUser.PercentVNP;
                    var parrentpecent = parrentUser.PercentVNP;
                    var pecentC1 = C1User.PercentVNP;


                    if (parrentUser.Type <= 2)
                        parrentpecent = pecent;

                    if (parrentUser.Type <= 3)
                        pecentC1 = parrentpecent;

                    if (parrentpecent < pecentC1)
                        parrentpecent = pecentC1;
                    if (pecent < parrentpecent)
                        pecent = parrentpecent;

                    if (int.Parse(order.TopupType) > 3)
                        continue;
                    //tạo order
                    var orderObj = new OrderInput
                    {
                        AccountName = order.Mobile,
                        AmountMin = order.AmountMin,
                        AmountMinAll = order.AmountMinAll,
                        Amount = order.Amount,
                        FullName = order.FullName,
                        Mobile = order.Mobile,
                        Password = order.Password,
                        Priority = CurrentFullUser.Piority,
                        Telco = "VNP",
                        Ussd = order.Ussd,
                        TopupType = order.TopupType,
                        Percent = pecent,
                        PercentParrent = parrentpecent,
                        PercentC1 = pecentC1

                    };
                    if (string.IsNullOrEmpty(orderObj.FullName))
                    {
                        orderObj.FullName = orderObj.Mobile;
                    }
                    orderObj.OrderNo = String.Format("{0}_{1}_{2}", CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);

                    //order của cấp 2
                    if (CurrentFullUser.Type == 4)
                    {
                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}", parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }
                    //order của cấp 4
                    if (CurrentFullUser.Type == 5)
                    {

                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}_{4}", C1User.Config, parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), order.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }
                    if (!string.IsNullOrEmpty(orderNo))
                        orderObj.OrderNo = orderObj.OrderNo + "_" + orderNo;
                    if (!string.IsNullOrEmpty(orderNo))
                    {
                        if (orderNo.StartsWith("RT_"))
                        {
                            orderObj.OrderNo = orderNo;
                        }
                    }    
                       

                    var amount = order.Amount;
                    amount = amount * pecent / 100;
                    lstOrderData.Add(orderObj);
                    totalAmountSucces += amount;

                }
                var resultDeduct = _transervice.DeductHold(CurrentFullUser.Username, totalAmountSucces, "Trừ tiền tạo giao dịch " + lstOrderData[0].OrderNo);
                if (resultDeduct < 0)
                {
                    switch (resultDeduct)
                    {
                        case -98: ReturnData.Description = "Số dư tài khoản không đủ để thực hiện giao dịch"; break;
                        default: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                    }
                    return Json(ReturnData);

                }

                var resultapi = ServerProcess.OrderAddMulti(lstOrderData, token, CurrentFullUser);
                //var resultapi = -1;
                if (resultapi <= 0)
                {
                    //lỗi thì hoàn tiền
                    _transervice.TopupHold(CurrentFullUser.Username, totalAmountSucces, "Hoàn tiền tạo giao dịch " + lstOrderData[0].OrderNo);
                    ReturnData.ResponseCode = resultapi;
                    ReturnData.Description = String.Format("Hệ thống đang bận. Vui lòng quay lại sau ({0})", resultapi);
                    return Json(ReturnData);

                }

                _userlogservice.InsertUsersLog(new UsersLog
                {
                    FunctionCode = "Orders",
                    Description = String.Format("Tạo giao dịch {0} số tiền trừ tạm :{1}", lstOrderData[0].OrderNo, totalAmountSucces),
                    UserID = CurrentFullUser.UserID,
                    UserName = CurrentFullUser.Username,
                    LogType = 1,
                    ClientIP = resultapi.ToString()
                });
                //if (totalAmountSucces > 0)
                //{
                //    _userservice.SetDay(CurrentFullUser.UserID, CurrentFullUser.CreatedUser, totalAmountSucces);
                //}
                ReturnData.ResponseCode = 1;
                ReturnData.Description = "Thành công";
                Session[SessionsManager.SESSION_USER_FULL] = null;
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Có lỗi trong quá trình xử lý";
            }

            return Json(ReturnData);

        }
        [PermissionFilter(FunctionCode = FunctionCode.OrderVTT)]
        public ActionResult OrderVTT()
        {

            if (CurrentUser == null)
                return RedirectToAction("Login", "Account");
            var user = _userservice.GetByUsername(CurrentUser.Username);
            if (!user.StatusVTT)
            {
                return RedirectToAction("Index", "Home");
            }
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                if (!parrent.StatusVTT)
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            ViewBag.MKBH = "";
            if (Session["MKBH"] != null)
            {
                ViewBag.MKBH = Session["MKBH"].ToString();
            }
            ViewBag.Order = user.StatusOrder;
            Session[SessionsManager.SESSION_USER_FULL] = user;
            return View(user);
        }
        [PermissionFilter(FunctionCode = FunctionCode.OrderZing)]
        public ActionResult OrderZing()
        {
            if (CurrentUser == null)
                return RedirectToAction("Login", "Account");
            var user = _userservice.GetByUsername(CurrentUser.Username);
            if (!user.StatusZing)
            {
                return RedirectToAction("Index", "Home");
            }
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                if (!parrent.StatusZing)
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            ViewBag.MKBH = "";
            if (Session["MKBH"] != null)
            {
                ViewBag.MKBH = Session["MKBH"].ToString();
            }
            ViewBag.Order = user.StatusOrder;
            Session[SessionsManager.SESSION_USER_FULL] = user;
            return View(user);
        }
        [PermissionFilter(FunctionCode = FunctionCode.OrderGRN)]
        public ActionResult OrderGarena()
        {
            if (CurrentUser == null)
                return RedirectToAction("Login", "Account");
            var user = _userservice.GetByUsername(CurrentUser.Username);
            if (!user.StatusGarena)
            {
                return RedirectToAction("Index", "Home");
            }
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                if (!parrent.StatusGarena)
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            ViewBag.MKBH = "";
            if (Session["MKBH"] != null)
            {
                ViewBag.MKBH = Session["MKBH"].ToString();
            }
            ViewBag.Order = user.StatusOrder;
            Session[SessionsManager.SESSION_USER_FULL] = user;
            return View(user);
        }
        [PermissionFilter(FunctionCode = FunctionCode.OrderVTC)]
        public ActionResult OrderVTC()
        {
            if (CurrentUser == null)
                return RedirectToAction("Login", "Account");
            var user = _userservice.GetByUsername(CurrentUser.Username);
            if (!user.StatusVTC)
            {
                return RedirectToAction("Index", "Home");
            }
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                if (!parrent.StatusVTC)
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            ViewBag.MKBH = "";
            if (Session["MKBH"] != null)
            {
                ViewBag.MKBH = Session["MKBH"].ToString();
            }
            ViewBag.Order = user.StatusOrder;
            Session[SessionsManager.SESSION_USER_FULL] = user;
            return View(user);
        }
        [HttpPost]
        public ActionResult OrderVTT(List<OrderModel> lstorder)
        {
            //tạm bỏ nạp hộ ussd
            //lstorder.RemoveAll(order => order.Telco == "VTT" && order.Ussd > 0 && order.TopupType == "1");

            var ReturnData = new ReturnData();
            try
            {
                if (CurrentFullUser == null)
                {

                    ReturnData.ResponseCode = -101;
                    ReturnData.Description = "Bạn không có quyền sử dụng chức năng này";
                    return Json(ReturnData);

                }
                var password = Encrypt.MD5(lstorder[0].Password2.Trim() + Config.GetAppsetting("Salt"));
                if (CurrentFullUser.Password2 != password)
                {
                    ReturnData.ResponseCode = -104;
                    ReturnData.Description = "Mật khẩu bán hàng không chính xác";
                    return Json(ReturnData);
                }
                Session["MKBH"] = lstorder[0].Password2.Trim();
                var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                if (string.IsNullOrEmpty(token))
                {
                    token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                    Session[SessionsManager.SESSION_TOKEN] = token;
                }
                var parrentUser = _userservice.GetByUsername(CurrentFullUser.CreatedUser);
                var C1User = parrentUser;
                if (CurrentFullUser.Type == 5)
                    C1User = _userservice.GetByUsername(parrentUser.CreatedUser);

                var pecent = CurrentFullUser.PercentVTT;
                int totalAmount = lstorder.Sum(x => x.Amount) / 100;
                int total = (totalAmount * pecent);
                if (CurrentFullUser.Balance < total)
                {
                    ReturnData.ResponseCode = -105;
                    ReturnData.Description = "Số dư không đủ để tạo đơn hàng";
                    return Json(ReturnData);
                }


                var orderNo = lstorder[0].OrderNo;
                if (!string.IsNullOrEmpty(orderNo))
                {
                    if (!orderNo.StartsWith("RT_"))
                        orderNo = StringUtils.FormatOrderNo(orderNo);
                }

                var totalAmountSucces = 0;
                var lstOrderData = new List<OrderInput>();
                foreach (var order in lstorder)
                {
                    pecent = CurrentFullUser.PercentVTT;
                    var parrentpecent = parrentUser.PercentVTT;
                    var pecentC1 = C1User.PercentVTT;
                    //if (order.Password.Length <= 5)
                    //    order.Password = "";
                    //không my
                    //if(!string.IsNullOrEmpty(order.Password))
                    //    order.Ussd = 0;
                    //if (((order.TopupType == "1" || order.TopupType == "2") && string.IsNullOrEmpty(order.Password)) || order.Ussd >= 1)
                    //order.Ussd = 0;
                    if (int.Parse(order.TopupType) > 5)
                        continue;
                    //trả sau
                    if (order.TopupType == "2" && (String.IsNullOrEmpty(order.Password) || order.Ussd > 0))
                    {

                        //tick ussd để mix

                        order.Ussd = 2;
                        if (CurrentFullUser.UserAPI != "chu_dl1_api")
                        {
                            pecent += int.Parse(Config.GetAppsetting("P1Ussd"));
                            parrentpecent += int.Parse(Config.GetAppsetting("P1Ussd"));
                            pecentC1 += int.Parse(Config.GetAppsetting("P1Ussd"));


                        }


                    }
                    if (order.TopupType == "3" && order.Ussd > 0)
                    {
                        //tick ussd để mix
                        order.Ussd = 2;

                        if (CurrentFullUser.UserAPI != "chu_dl1_api")
                        {
                            pecent += int.Parse(Config.GetAppsetting("P1Ussd"));
                            parrentpecent += int.Parse(Config.GetAppsetting("P1Ussd"));
                            pecentC1 += int.Parse(Config.GetAppsetting("P1Ussd"));
                        }
                    }

                    if (order.TopupType == "5")
                    {
                        order.Ussd = 2;


                        //pecent += int.Parse(Config.GetAppsetting("P1Ussd"));
                        //parrentpecent += int.Parse(Config.GetAppsetting("P1Ussd"));
                    }

                    //trả trước ussd=0
                    if (order.TopupType == "1")
                    {
                        order.Ussd = 0;
                    }


                    //nạp hộ trả trước
                    if (order.TopupType == "1" && String.IsNullOrEmpty(order.Password))
                    {
                        continue;
                    }
                    if (order.Mobile.StartsWith("02") | order.Mobile.StartsWith("2"))
                    {
                        continue;
                    }
                    if (order.Amount < 5000)
                        continue;
                    if (!string.IsNullOrEmpty(order.Password) && order.Ussd == 0)
                    {
                        if (order.Password.Length < 6)
                            continue;
                    }
                    if (parrentUser.Type <= 2)
                        parrentpecent = pecent;

                    if (parrentUser.Type <= 3)
                        pecentC1 = parrentpecent;

                    if (parrentpecent < pecentC1)
                        parrentpecent = pecentC1;
                    if (pecent < parrentpecent)
                        pecent = parrentpecent;
                    //tạo order
                    var orderObj = new OrderInput
                    {
                        AccountName = order.Mobile,
                        AmountMin = order.AmountMin,
                        AmountMinAll = order.AmountMinAll,
                        Amount = order.Amount,
                        FullName = order.FullName,
                        Mobile = order.Mobile,
                        Password = order.Password,
                        Priority = CurrentFullUser.Piority,
                        Telco = "VTT",
                        Ussd = order.Ussd,
                        TopupType = order.TopupType,
                        Percent = pecent,
                        PercentParrent = parrentpecent,
                        PercentC1 = pecentC1

                    };
                    if (string.IsNullOrEmpty(orderObj.FullName))
                    {
                        orderObj.FullName = orderObj.Mobile;
                    }
                    orderObj.OrderNo = String.Format("{0}_{1}_{2}", CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);

                    //order của cấp 2
                    if (CurrentFullUser.Type == 4)
                    {

                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}", parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }
                    //cấp 3
                    if (CurrentFullUser.Type == 5)
                    {

                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}_{4}", C1User.Config, parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), order.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }
                    //cộng thêm order
                    if (!string.IsNullOrEmpty(orderNo))
                        orderObj.OrderNo = orderObj.OrderNo + "_" + orderNo;

                    if (!string.IsNullOrEmpty(orderNo))
                    {
                        if (orderNo.StartsWith("RT_"))
                        {
                            orderObj.OrderNo = orderNo;
                        }
                    }
                    var amount = order.Amount;
                    amount = amount * pecent / 100;

                    totalAmountSucces += amount;

                    lstOrderData.Add(orderObj);
                }
                var resultDeduct = _transervice.DeductHold(CurrentFullUser.Username, totalAmountSucces, "Trừ tiền tạo giao dịch " + lstOrderData[0].OrderNo);
                if (resultDeduct < 0)
                {
                    switch (resultDeduct)
                    {
                        case -98: ReturnData.Description = "Số dư tài khoản không đủ để thực hiện giao dịch"; break;
                        default: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                    }
                    return Json(ReturnData);

                }

                var resultapi = ServerProcess.OrderAddMulti(lstOrderData, token, CurrentFullUser);
                //var resultapi = -1;
                if (resultapi <= 0)
                {
                    //lỗi thì hoàn tiền
                    _transervice.TopupHold(CurrentFullUser.Username, totalAmountSucces, "Hoàn tiền tạo giao dịch " + lstOrderData[0].OrderNo);
                    ReturnData.ResponseCode = resultapi;
                    ReturnData.Description = String.Format("Hệ thống đang bận. Vui lòng quay lại sau ({0})", resultapi);
                    return Json(ReturnData);

                }

                _userlogservice.InsertUsersLog(new UsersLog
                {
                    FunctionCode = "Orders",
                    Description = String.Format("Tạo giao dịch {0} số tiền trừ tạm :{1}", lstOrderData[0].OrderNo, totalAmountSucces),
                    UserID = CurrentFullUser.UserID,
                    UserName = CurrentFullUser.Username,
                    LogType = 1,
                    ClientIP = resultapi.ToString()
                });
                //if (totalAmountSucces > 0)
                //{
                //    _userservice.SetDay(CurrentFullUser.UserID, CurrentFullUser.CreatedUser, totalAmountSucces);
                //}

                ReturnData.ResponseCode = 1;
                ReturnData.Description = "Thành công";
                Session[SessionsManager.SESSION_USER_FULL] = null;
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Có lỗi trong quá trình xử lý";
            }

            return Json(ReturnData);

        }
        [HttpPost]
        public ActionResult OrderZing(List<OrderModel> lstorder)
        {
            var ReturnData = new ReturnData();
            try
            {
                if (CurrentFullUser == null)
                {

                    ReturnData.ResponseCode = -101;
                    ReturnData.Description = "Bạn không có quyền sử dụng chức năng này";
                    return Json(ReturnData);

                }
                var password = Encrypt.MD5(lstorder[0].Password2.Trim() + Config.GetAppsetting("Salt"));
                if (CurrentFullUser.Password2 != password)
                {
                    ReturnData.ResponseCode = -104;
                    ReturnData.Description = "Mật khẩu bán hàng không chính xác";
                    return Json(ReturnData);
                }
                Session["MKBH"] = lstorder[0].Password2.Trim();
                var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                if (string.IsNullOrEmpty(token))
                {
                    token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                    Session[SessionsManager.SESSION_TOKEN] = token;
                }
                var parrentUser = _userservice.GetByUsername(CurrentFullUser.CreatedUser);
                var C1User = parrentUser;
                if (CurrentFullUser.Type == 5)
                    C1User = _userservice.GetByUsername(parrentUser.CreatedUser);
                var pecent = CurrentFullUser.PercentZing;
                int totalAmount = lstorder.Sum(x => x.Amount) / 100;
                int total = (totalAmount * pecent);
                if (CurrentFullUser.Balance < total)
                {
                    ReturnData.ResponseCode = -105;
                    ReturnData.Description = "Số dư không đủ để tạo đơn hàng";
                    return Json(ReturnData);
                }

                var orderNo = lstorder[0].OrderNo;
                if (!string.IsNullOrEmpty(orderNo))
                {
                    if (!orderNo.StartsWith("RT_"))
                        orderNo = StringUtils.FormatOrderNo(orderNo);
                }
                var totalAmountSucces = 0;
                var lstOrderData = new List<OrderInput>();
                var lstOrderTemp = new List<OrderInput>();
                foreach (var order in lstorder)
                {
                    pecent = CurrentFullUser.PercentZing;
                    var parrentpecent = parrentUser.PercentZing;
                    var pecentC1 = C1User.PercentZing;
                    if (parrentUser.Type <= 2)
                        parrentpecent = pecent;

                    if (parrentUser.Type <= 3)
                        pecentC1 = parrentpecent;

                    if (parrentpecent < pecentC1)
                        parrentpecent = pecentC1;

                    if (pecent < parrentpecent)
                        pecent = parrentpecent;
                    //tạo order
                    var orderObj = new OrderInput
                    {
                        AccountName = order.Mobile,
                        AmountMin = order.AmountMin,
                        AmountMinAll = order.AmountMinAll,
                        Amount = order.Amount,
                        FullName = order.FullName,
                        Mobile = order.Mobile,
                        Password = order.Password,
                        Priority = CurrentFullUser.Piority,
                        Telco = "Zing",
                        Ussd = order.Ussd,
                        TopupType = order.TopupType,
                        Percent = pecent,
                        PercentParrent = parrentpecent,
                        PercentC1 = pecentC1
                    };
                    if (string.IsNullOrEmpty(orderObj.FullName))
                    {
                        orderObj.FullName = orderObj.Mobile;
                    }
                    orderObj.OrderNo = String.Format("{0}_{1}_{2}", CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);

                    //order của cấp 2
                    if (CurrentFullUser.Type == 4)
                    {

                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}", parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }
                    //cấp 3
                    if (CurrentFullUser.Type == 5)
                    {

                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}_{4}", C1User.Config, parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), order.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }
                    //order của cấp 4
                    if (!string.IsNullOrEmpty(orderNo))
                        orderObj.OrderNo = orderObj.OrderNo + "_" + orderNo;
                    if (!string.IsNullOrEmpty(orderNo))
                    {
                        if (orderNo.StartsWith("RT_"))
                        {
                            orderObj.OrderNo = orderNo;
                        }
                    }
                    var amount = order.Amount;
                    amount = amount * pecent / 100;
                    if (order.TopupType == "16" || order.TopupType == "17")
                    {


                        lstOrderTemp.Add(orderObj);
                    }
                    else
                    {
                        totalAmountSucces += amount;
                        lstOrderData.Add(orderObj);
                    }

                }
                if (totalAmountSucces > 0)
                {
                    var resultDeduct = _transervice.DeductHold(CurrentFullUser.Username, totalAmountSucces, "Trừ tiền tạo giao dịch " + lstOrderData[0].OrderNo);
                    if (resultDeduct < 0)
                    {
                        switch (resultDeduct)
                        {
                            case -98: ReturnData.Description = "Số dư tài khoản không đủ để thực hiện giao dịch"; break;
                            default: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                        }
                        return Json(ReturnData);

                    }

                    var resultapi = ServerProcess.OrderAddMulti(lstOrderData, token, CurrentFullUser);
                    //var resultapi = -1;
                    if (resultapi <= 0)
                    {
                        //lỗi thì hoàn tiền
                        _transervice.TopupHold(CurrentFullUser.Username, totalAmountSucces, "Hoàn tiền tạo giao dịch " + lstOrderData[0].OrderNo);
                        ReturnData.ResponseCode = resultapi;
                        ReturnData.Description = String.Format("Hệ thống đang bận. Vui lòng quay lại sau ({0})", resultapi);
                        return Json(ReturnData);

                    }

                    _userlogservice.InsertUsersLog(new UsersLog
                    {
                        FunctionCode = "Orders",
                        Description = String.Format("Tạo giao dịch {0} số tiền trừ tạm :{1}", lstOrderData[0].OrderNo, totalAmountSucces),
                        UserID = CurrentFullUser.UserID,
                        UserName = CurrentFullUser.Username,
                        LogType = 1,
                        ClientIP = resultapi.ToString()
                    });
                }
                if (lstOrderTemp.Count > 0)
                {
                    foreach (var temp in lstOrderTemp)
                    {
                        temp.CreateUser = CurrentFullUser.Username;
                        _oservice.InsertUpdate(temp);
                    }
                }

                ReturnData.ResponseCode = 1;
                ReturnData.Description = "Thành công";
                Session[SessionsManager.SESSION_USER_FULL] = null;
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Có lỗi trong quá trình xử lý";
            }

            return Json(ReturnData);

        }
        [HttpPost]
        public ActionResult OrderGarena(List<OrderModel> lstorder)
        {
            var ReturnData = new ReturnData();
            try
            {
                if (CurrentFullUser == null)
                {

                    ReturnData.ResponseCode = -101;
                    ReturnData.Description = "Bạn không có quyền sử dụng chức năng này";
                    return Json(ReturnData);

                }
                var password = Encrypt.MD5(lstorder[0].Password2.Trim() + Config.GetAppsetting("Salt"));
                if (CurrentFullUser.Password2 != password)
                {
                    ReturnData.ResponseCode = -104;
                    ReturnData.Description = "Mật khẩu bán hàng không chính xác";
                    return Json(ReturnData);
                }
                Session["MKBH"] = lstorder[0].Password2.Trim();
                var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                if (string.IsNullOrEmpty(token))
                {
                    token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                    Session[SessionsManager.SESSION_TOKEN] = token;
                }
                var parrentUser = _userservice.GetByUsername(CurrentFullUser.CreatedUser);
                var C1User = parrentUser;
                if (CurrentFullUser.Type == 5)
                    C1User = _userservice.GetByUsername(parrentUser.CreatedUser);
                var pecent = CurrentFullUser.PercentGarena;
                int totalAmount = lstorder.Sum(x => x.Amount) / 100;
                int total = (totalAmount * pecent);
                if (CurrentFullUser.Balance < total)
                {
                    ReturnData.ResponseCode = -105;
                    ReturnData.Description = "Số dư không đủ để tạo đơn hàng";
                    return Json(ReturnData);
                }

                var orderNo = lstorder[0].OrderNo;
                if (!string.IsNullOrEmpty(orderNo))
                {
                    if (!orderNo.StartsWith("RT_"))
                        orderNo = StringUtils.FormatOrderNo(orderNo);
                }
                var totalAmountSucces = 0;
                var lstOrderData = new List<OrderInput>();
                foreach (var order in lstorder)
                {
                    pecent = CurrentFullUser.PercentGarena;
                    var parrentpecent = parrentUser.PercentGarena;
                    var pecentC1 = C1User.PercentGarena;

                    if (parrentUser.Type <= 2)
                        parrentpecent = pecent;

                    if (parrentUser.Type <= 3)
                        pecentC1 = parrentpecent;

                    if (parrentpecent < pecentC1)
                        parrentpecent = pecentC1;

                    if (pecent < parrentpecent)
                        pecent = parrentpecent;
                    //tạo order
                    if (string.IsNullOrEmpty(order.TopupType))
                        order.TopupType = "9";
                    var orderObj = new OrderInput
                    {
                        AccountName = order.Mobile,
                        AmountMin = order.AmountMin,
                        AmountMinAll = order.AmountMinAll,
                        Amount = order.Amount,
                        FullName = order.FullName,
                        Mobile = order.Mobile,
                        Password = order.Password,
                        Priority = CurrentFullUser.Piority,
                        Telco = "Garena",
                        Ussd = order.Ussd,
                        TopupType = order.TopupType,
                        Percent = pecent,
                        PercentParrent = parrentpecent,
                        PercentC1 = pecentC1
                    };
                    if (string.IsNullOrEmpty(orderObj.FullName))
                    {
                        orderObj.FullName = orderObj.Mobile;
                    }
                    orderObj.OrderNo = String.Format("{0}_{1}_{2}", CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);

                    //order của cấp 2
                    if (CurrentFullUser.Type == 4)
                    {

                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}", parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }
                    //cấp 3
                    if (CurrentFullUser.Type == 5)
                    {

                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}_{4}", C1User.Config, parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), order.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }
                    if (!string.IsNullOrEmpty(orderNo))
                        orderObj.OrderNo = orderObj.OrderNo + "_" + orderNo;
                    if (!string.IsNullOrEmpty(orderNo))
                    {
                        if (orderNo.StartsWith("RT_"))
                        {
                            orderObj.OrderNo = orderNo;
                        }
                    }
                    var amount = order.Amount;
                    amount = amount * pecent / 100;

                    totalAmountSucces += amount;
                    lstOrderData.Add(orderObj);
                }
                var resultDeduct = _transervice.DeductHold(CurrentFullUser.Username, totalAmountSucces, "Trừ tiền tạo giao dịch " + lstOrderData[0].OrderNo);
                if (resultDeduct < 0)
                {
                    switch (resultDeduct)
                    {
                        case -98: ReturnData.Description = "Số dư tài khoản không đủ để thực hiện giao dịch"; break;
                        default: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                    }
                    return Json(ReturnData);

                }

                var resultapi = ServerProcess.OrderAddMulti(lstOrderData, token, CurrentFullUser);
                //var resultapi = -1;
                if (resultapi <= 0)
                {
                    //lỗi thì hoàn tiền
                    _transervice.TopupHold(CurrentFullUser.Username, totalAmountSucces, "Hoàn tiền tạo giao dịch " + lstOrderData[0].OrderNo);
                    ReturnData.ResponseCode = resultapi;
                    ReturnData.Description = String.Format("Hệ thống đang bận. Vui lòng quay lại sau ({0})", resultapi);
                    return Json(ReturnData);

                }

                _userlogservice.InsertUsersLog(new UsersLog
                {
                    FunctionCode = "Orders",
                    Description = String.Format("Tạo giao dịch {0} số tiền trừ tạm :{1}", lstOrderData[0].OrderNo, totalAmountSucces),
                    UserID = CurrentFullUser.UserID,
                    UserName = CurrentFullUser.Username,
                    LogType = 1,
                    ClientIP = resultapi.ToString()
                });
                ReturnData.ResponseCode = 1;
                ReturnData.Description = "Thành công";
                Session[SessionsManager.SESSION_USER_FULL] = null;
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Có lỗi trong quá trình xử lý";
            }

            return Json(ReturnData);

        }
        [HttpPost]
        public ActionResult OrderVTC(List<OrderModel> lstorder)
        {
            var ReturnData = new ReturnData();
            try
            {
                if (CurrentFullUser == null)
                {

                    ReturnData.ResponseCode = -101;
                    ReturnData.Description = "Bạn không có quyền sử dụng chức năng này";
                    return Json(ReturnData);

                }
                var password = Encrypt.MD5(lstorder[0].Password2.Trim() + Config.GetAppsetting("Salt"));
                if (CurrentFullUser.Password2 != password)
                {
                    ReturnData.ResponseCode = -104;
                    ReturnData.Description = "Mật khẩu bán hàng không chính xác";
                    return Json(ReturnData);
                }
                Session["MKBH"] = lstorder[0].Password2.Trim();
                var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                if (string.IsNullOrEmpty(token))
                {
                    token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                    Session[SessionsManager.SESSION_TOKEN] = token;
                }
                var parrentUser = _userservice.GetByUsername(CurrentFullUser.CreatedUser);
                var pecent = CurrentFullUser.PercentVTC;
                int totalAmount = lstorder.Sum(x => x.Amount) / 100;
                int total = (totalAmount * pecent);
                if (CurrentFullUser.Balance < total)
                {
                    ReturnData.ResponseCode = -105;
                    ReturnData.Description = "Số dư không đủ để tạo đơn hàng";
                    return Json(ReturnData);
                }

                var orderNo = lstorder[0].OrderNo;
                if (!string.IsNullOrEmpty(orderNo))
                {
                    if (!orderNo.StartsWith("RT_"))
                        orderNo = StringUtils.FormatOrderNo(orderNo);
                }
                var totalAmountSucces = 0;
                var lstOrderData = new List<OrderInput>();
                foreach (var order in lstorder)
                {
                    pecent = CurrentFullUser.PercentVTC;
                    var parrentpecent = parrentUser.PercentVTC;

                    if (parrentUser.Type <= 2)
                        parrentpecent = pecent;

                    if (pecent < parrentpecent)
                        pecent = parrentpecent;
                    //tạo order
                    var orderObj = new OrderInput
                    {
                        AccountName = order.Mobile,
                        AmountMin = order.AmountMin,
                        AmountMinAll = order.AmountMinAll,
                        Amount = order.Amount,
                        FullName = order.FullName,
                        Mobile = order.Mobile,
                        Password = order.Password,
                        Priority = CurrentFullUser.Piority,
                        Telco = "VTC",
                        Ussd = order.Ussd,
                        TopupType = "9",
                        Percent = pecent,
                        PercentParrent = parrentpecent,
                        PercentC1 = parrentpecent
                    };
                    if (string.IsNullOrEmpty(orderObj.FullName))
                    {
                        orderObj.FullName = orderObj.Mobile;
                    }
                    orderObj.OrderNo = String.Format("{0}_{1}_{2}", CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);

                    //order của cấp 2
                    if (CurrentFullUser.Type >= 4)
                    {

                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}", parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }

                    //order của cấp 4
                    if (!string.IsNullOrEmpty(orderNo))
                        orderObj.OrderNo = orderObj.OrderNo + "_" + orderNo;

                    if (!string.IsNullOrEmpty(orderNo))
                    {
                        if (orderNo.StartsWith("RT_"))
                        {
                            orderObj.OrderNo = orderNo;
                        }
                    }
                    var amount = order.Amount;
                    amount = amount * pecent / 100;

                    totalAmountSucces += amount;
                    lstOrderData.Add(orderObj);
                }
                var resultDeduct = _transervice.DeductHold(CurrentFullUser.Username, totalAmountSucces, "Trừ tiền tạo giao dịch " + lstOrderData[0].OrderNo);
                if (resultDeduct < 0)
                {
                    switch (resultDeduct)
                    {
                        case -98: ReturnData.Description = "Số dư tài khoản không đủ để thực hiện giao dịch"; break;
                        default: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                    }
                    return Json(ReturnData);

                }

                var resultapi = ServerProcess.OrderAddMulti(lstOrderData, token, CurrentFullUser);
                //var resultapi = -1;
                if (resultapi <= 0)
                {
                    //lỗi thì hoàn tiền
                    _transervice.TopupHold(CurrentFullUser.Username, totalAmountSucces, "Hoàn tiền tạo giao dịch " + lstOrderData[0].OrderNo);
                    ReturnData.ResponseCode = resultapi;
                    ReturnData.Description = String.Format("Hệ thống đang bận. Vui lòng quay lại sau ({0})", resultapi);
                    return Json(ReturnData);

                }

                _userlogservice.InsertUsersLog(new UsersLog
                {
                    FunctionCode = "Orders",
                    Description = String.Format("Tạo giao dịch {0} số tiền trừ tạm :{1}", lstOrderData[0].OrderNo, totalAmountSucces),
                    UserID = CurrentFullUser.UserID,
                    UserName = CurrentFullUser.Username,
                    LogType = 1,
                    ClientIP = resultapi.ToString()
                });
                //if (totalAmountSucces > 0)
                //{
                //    _userservice.SetDay(CurrentFullUser.UserID, CurrentFullUser.CreatedUser, totalAmountSucces);
                //}
                ReturnData.ResponseCode = 1;
                ReturnData.Description = "Thành công";
                Session[SessionsManager.SESSION_USER_FULL] = null;
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Có lỗi trong quá trình xử lý";
            }

            return Json(ReturnData);

        }
        [HttpPost]
        public ActionResult OrderVMS(List<OrderModel> lstorder)
        {
            var ReturnData = new ReturnData();
            try
            {
                if (CurrentFullUser == null)
                {

                    ReturnData.ResponseCode = -101;
                    ReturnData.Description = "Bạn không có quyền sử dụng chức năng này";
                    return Json(ReturnData);

                }
                var password = Encrypt.MD5(lstorder[0].Password2.Trim() + Config.GetAppsetting("Salt"));
                if (CurrentFullUser.Password2 != password)
                {
                    ReturnData.ResponseCode = -104;
                    ReturnData.Description = "Mật khẩu bán hàng không chính xác";
                    return Json(ReturnData);
                }
                Session["MKBH"] = lstorder[0].Password2.Trim();
                var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                if (string.IsNullOrEmpty(token))
                {
                    token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                    Session[SessionsManager.SESSION_TOKEN] = token;
                }
                var data = ServerProcess.ListTransaction(token, 1000, "VMS", "", null, 0);

                var parrentUser = _userservice.GetByUsername(CurrentFullUser.CreatedUser);
                var C1User = parrentUser;
                if (CurrentFullUser.Type == 5)
                    C1User = _userservice.GetByUsername(parrentUser.CreatedUser);
                var pecent = CurrentFullUser.PercentVMS;

                int totalAmount = lstorder.Sum(x => x.Amount) / 100;
                int total = (totalAmount * pecent);
                if (CurrentFullUser.Balance < total)
                {
                    ReturnData.ResponseCode = -105;
                    ReturnData.Description = "Số dư không đủ để tạo đơn hàng";
                    return Json(ReturnData);
                }

                var orderNo = lstorder[0].OrderNo;
                if (!string.IsNullOrEmpty(orderNo))
                {
                    if (!orderNo.StartsWith("RT_"))
                        orderNo = StringUtils.FormatOrderNo(orderNo);
                }
                var totalAmountSucces = 0;

                foreach (var order in lstorder)
                {
                    //tạo order
                    pecent = CurrentFullUser.PercentVMS;
                    var parrentpecent = parrentUser.PercentVMS;
                    var pecentC1 = C1User.PercentVMS;

                    if (parrentUser.Type <= 2)
                        parrentpecent = pecent;

                    if (parrentUser.Type <= 3)
                        pecentC1 = parrentpecent;
                    if (parrentpecent < pecentC1)
                        parrentpecent = pecentC1;

                    if (pecent < parrentpecent)
                        pecent = parrentpecent;

                    var orderObj = new OrderInput
                    {
                        AccountName = order.Mobile,
                        AmountMin = order.AmountMin,
                        AmountMinAll = order.AmountMinAll,
                        Amount = order.Amount,
                        FullName = order.FullName,
                        Mobile = order.Mobile,
                        Password = order.Password,
                        Priority = CurrentFullUser.Piority,
                        Telco = "VMS",
                        Ussd = order.Ussd,
                        TopupType = order.TopupType,
                        Percent = pecent,
                        PercentParrent = parrentpecent,
                        PercentC1 = parrentpecent
                    };
                    if (string.IsNullOrEmpty(orderObj.FullName))
                    {
                        orderObj.FullName = orderObj.Mobile;
                    }
                    orderObj.OrderNo = String.Format("{0}_{1}_{2}", CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);

                    //order của cấp 2
                    if (CurrentFullUser.Type == 4)
                    {

                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}", parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), orderObj.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }
                    //cấp 3
                    if (CurrentFullUser.Type == 5)
                    {

                        orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}_{4}", C1User.Config, parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), order.Telco);
                        orderObj.Priority = parrentUser.Piority;
                    }
                    //ton tai sdt
                    if (data.Exists(x => x.Mobile.Equals(orderObj.Mobile)))
                    {
                        continue;
                    }
                    if (!string.IsNullOrEmpty(orderNo))

                        orderObj.OrderNo = orderObj.OrderNo + "_" + orderNo;

                    if (!string.IsNullOrEmpty(orderNo))
                    {
                        if (orderNo.StartsWith("RT_"))
                        {
                            orderObj.OrderNo = orderNo;
                        }
                    }
                    var amount = order.Amount;
                    amount = amount * pecent / 100;

                    //get Password
                    if (string.IsNullOrEmpty(orderObj.Password))
                    {
                        orderObj.Password = ServerProcess.GetTelco(orderObj.Mobile, orderObj.Telco.ToLower(), token);
                    }

                    if (!string.IsNullOrEmpty(orderObj.Password))
                    {
                        var resultDeduct = _transervice.DeductHold(CurrentFullUser.Username, amount, "Trừ tiền tạo giao dịch " + orderObj.OrderNo);
                        if (resultDeduct < 0)
                        {
                            switch (resultDeduct)
                            {
                                case -98: ReturnData.Description = "Số dư tài khoản không đủ để thực hiện giao dịch"; break;
                                default: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                            }
                            return Json(ReturnData);

                        }

                        var resultapi = ServerProcess.OrderAdd(orderObj, token, CurrentFullUser, pecent, parrentpecent, pecentC1);
                        //var resultapi = -1;
                        if (resultapi <= 0)
                        {
                            //lỗi thì hoàn tiền
                            _transervice.TopupHold(CurrentFullUser.Username, amount, "Hoàn tiền tạo giao dịch " + orderObj.OrderNo);
                            ReturnData.ResponseCode = resultapi;
                            ReturnData.Description = String.Format("Hệ thống đang bận. Vui lòng quay lại sau ({0})", resultapi);
                            return Json(ReturnData);

                        }

                        _userlogservice.InsertUsersLog(new UsersLog
                        {
                            FunctionCode = "Orders",
                            Description = String.Format("Tạo giao dịch {0}-{1} số tiền trừ tạm :{2} chiết khấu :{3}", orderObj.OrderNo, resultapi, amount, 100 - pecent),
                            UserID = CurrentFullUser.UserID,
                            UserName = CurrentFullUser.Username,
                            LogType = pecent,
                            ClientIP = resultapi.ToString()
                        });
                        totalAmountSucces += amount;
                        ReturnData.ResponseCode = resultapi;
                        System.Threading.Thread.Sleep(200);
                    }
                    //inser don tam
                    else
                    {
                        orderObj.CreateUser = CurrentFullUser.Username;
                        _oservice.InsertUpdate(orderObj);
                    }

                }

                ReturnData.ResponseCode = 1;
                ReturnData.Description = "Thành công";
                Session[SessionsManager.SESSION_USER_FULL] = null;
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Có lỗi trong quá trình xử lý";
            }

            return Json(ReturnData);

        }
        [PermissionFilter(FunctionCode = FunctionCode.OrderVMS)]
        public ActionResult OrderVMS()
        {

            if (CurrentUser == null)
                return RedirectToAction("Login", "Account");

            var user = _userservice.GetByUsername(CurrentUser.Username);
            if (!user.StatusVMS)
            {
                return RedirectToAction("Index", "Home");
            }
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                if (!parrent.StatusVMS)
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            ViewBag.MKBH = "";
            if (Session["MKBH"] != null)
            {
                ViewBag.MKBH = Session["MKBH"].ToString();
            }
            ViewBag.Order = user.StatusOrder;
            Session[SessionsManager.SESSION_USER_FULL] = user;
            return View(user);
        }
        public ActionResult ErrorPermission()
        {


            return View();
        }
        public ActionResult ErrorNotPage()
        {


            return View();
        }


        public ActionResult Header()
        {
            // var userinfo = (UserSession)Session[SessionsManager.SESSION_USER];
            var user = _userservice.GetByUsername(CurrentUser.Username);
            return PartialView(user);
        }
        public ActionResult Balance(Users user)
        {

            ViewBag.Balance = user.Balance;
            ViewBag.BalanceHold = user.BalanceHold > 0 ? user.BalanceHold : 0;
            return PartialView();
        }
        public ActionResult StatusBarGame(Users user = null)
        {
            //if (user != null)
            //{

            //    return PartialView(user);
            //}
            var userinfo = (UserSession)Session[SessionsManager.SESSION_USER];
            user = _userservice.SelectByUserID(userinfo.UserID);
            ViewBag.Balance = user.Balance;
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                user.StatusGarena = user.StatusGarena && parrent.StatusGarena;
                user.StatusZing = user.StatusZing && parrent.StatusZing;
                user.StatusVTC = user.StatusVTC && parrent.StatusVTC;
            }
            return PartialView(user);
        }
        [OutputCache(Duration = 600, VaryByParam = "*", VaryByCustom = "browser")]
        public ActionResult TopCkBar(int type = 1)
        {

            var data = _orderservice.GetMaxBid();
            if (type == 1)
            {
                data = data.Where(x => x.Telco == "VTT" || x.Telco == "VNP" || x.Telco == "VMS").ToList();
            }
            else
            {
                data = data.Where(x => x.Telco != "VTT" && x.Telco != "VNP" && x.Telco != "VMS").ToList();
            }
            return PartialView(data);
        }
        public ActionResult StatusBar(Users user = null)
        {

            var userinfo = (UserSession)Session[SessionsManager.SESSION_USER];
            user = _userservice.GetByUsername(userinfo.Username);
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                user.StatusVTT = user.StatusVTT && parrent.StatusVTT;
                user.StatusVMS = user.StatusVMS && parrent.StatusVMS;
                user.StatusVNP = user.StatusVNP && parrent.StatusVNP;
            }
            ViewBag.Balance = user.Balance;
            return PartialView(user);
        }
        public ActionResult StatusBar2(Users user = null)
        {

            if (user != null)
            {

                return PartialView(user);
            }
            var userinfo = (UserSession)Session[SessionsManager.SESSION_USER];
            user = _userservice.GetByUsername(userinfo.Username);
            ViewBag.Balance = user.Balance;
            return PartialView(user);
        }
        public ActionResult Menu()
        {
            var userinfo = (UserSession)Session[SessionsManager.SESSION_USER];
            if (CurrentFullUser == null)
            {
                var m_Users = _userservice.GetByUsername(CurrentUser.Username);
                Session[SessionsManager.SESSION_USER_FULL] = m_Users;
                CurrentFullUser = m_Users;
            }
            var functions = (List<Functions>)Session[SessionsManager.SESSION_FUNCTIONS];
            if (userinfo == null)
            {
                return PartialView(null);
            }
            if (functions == null)
            {
                if (userinfo.Type == 1)
                {
                    Session[SessionsManager.SESSION_FUNCTIONS] = _functionservice.GetListFunctionBySystemID(0);
                    Session[SessionsManager.SESSION_USERFUNCTIONS] = new List<UserFunction>();
                }
                else
                {
                    /*bo quyen theo user*/
                    //functions= _functionservice.GetListFunctionByUserID(userinfo.UserID); 
                    //Session[SessionsManager.SESSION_USERFUNCTIONS] = _userroleservice.UserFunction_GetByUserID(userinfo.UserID);

                    functions = _userroleservice.GetListFunctionByID(userinfo.Type);
                    Session[SessionsManager.SESSION_USERFUNCTIONS] = _userroleservice.GroupFunction_GetByID(userinfo.Type);
                }
            }
            ViewBag.UserType = CurrentFullUser.Type;
            ViewBag.IsUserGame = CurrentFullUser.StatusZing || CurrentFullUser.StatusGarena || CurrentFullUser.StatusVTC;
            ViewBag.IsUserTelco = CurrentFullUser.StatusVMS || CurrentFullUser.StatusVTT || CurrentFullUser.StatusVNP;
            ViewBag.IsZing = CurrentFullUser.StatusZing;
            ViewBag.IsVTC = CurrentFullUser.StatusVTC;
            ViewBag.IsGarena = CurrentFullUser.StatusGarena;
            ViewBag.IsVMS = CurrentFullUser.StatusVMS;
            ViewBag.IsVTT = CurrentFullUser.StatusVTT;
            ViewBag.IsVNP = CurrentFullUser.StatusVNP;
            Session[SessionsManager.SESSION_FUNCTIONS] = functions;
            return PartialView(functions);
        }
        public ActionResult FormOrder(Users user = null)
        {
            ViewBag.DevideId = Encrypt.MD5V2(DateTime.Now.ToString()).Substring(0, 0x10).ToLower();
            ViewBag.TokenUrl = Config.GetAppsetting("Api_MobileToken");
            ViewBag.MKBH = "";
            if (Session["MKBH"] != null)
            {
                ViewBag.MKBH = Session["MKBH"].ToString();
            }


            //if (user != null)
            //{

            //    return PartialView(user);
            //}
            var userinfo = (UserSession)Session[SessionsManager.SESSION_USER];
            user = _userservice.SelectByUserID(userinfo.UserID);
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                user.StatusVTT = user.StatusVTT && parrent.StatusVTT;
                user.StatusVMS = user.StatusVMS && parrent.StatusVMS;
                user.StatusVNP = user.StatusVNP && parrent.StatusVNP;
            }
            return PartialView(user);
        }
        public ActionResult FormOrderGame(Users user = null)
        {
            ViewBag.DevideId = Encrypt.MD5V2(DateTime.Now.ToString()).Substring(0, 0x10).ToLower();
            ViewBag.TokenUrl = Config.GetAppsetting("Api_MobileToken");
            ViewBag.MKBH = "";
            if (Session["MKBH"] != null)
            {
                ViewBag.MKBH = Session["MKBH"].ToString();
            }


            //if (user != null)
            //{

            //    return PartialView(user);
            //}
            var userinfo = (UserSession)Session[SessionsManager.SESSION_USER];
            user = _userservice.SelectByUserID(userinfo.UserID);
            if (user.Type > 3)
            {
                var parrent = _userservice.GetByUsername(user.CreatedUser);
                user.StatusGarena = user.StatusGarena && parrent.StatusGarena;
                user.StatusZing = user.StatusZing && parrent.StatusZing;
                user.StatusVTC = user.StatusVTC && parrent.StatusVTC;
            }

            return PartialView(user);
        }
        public ActionResult ListTransactionOrder(string Telco = "")
        {
            var token = Session[SessionsManager.SESSION_TOKEN].ToString();
            if (string.IsNullOrEmpty(token))
            {
                token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                Session[SessionsManager.SESSION_TOKEN] = token;
            }
            //var orderNo = ServerProcess.getSearchOrder(CurrentFullUser, true);
            var data = ServerProcess.ListTransaction(token, 100, Telco, null, null, null, CurrentFullUser.Username);



            //tk cấp 1 chỉ nhìn đc nó
            //if (CurrentFullUser.Type <= 3)
            //{
            //    data = data.Where(x => x.OrderNo.ToCharArray().Count(c => c == '_') == 2).ToList();

            //}
            ViewBag.Username = CurrentUser.Username;
            //ViewBag.IsBid = ConfigurationManager.AppSettings["UsersBid"].ToString().Contains("," + CurrentFullUser.Username + ",") || ConfigurationManager.AppSettings["UsersAPIBid"].ToString().Contains("," + CurrentFullUser.UserAPI + ",");
            return PartialView(data.Take(18).ToList());
        }
        public ActionResult ListOrderTemp(string Telco)
        {
            var data = _oservice.GetFilter(CurrentUser.Username);
            data = data.Where(x => x.Telco == Telco).ToList();
            ViewBag.TokenUrl = Config.GetAppsetting("Api_MobileToken");


            return PartialView(data);
        }
        [HttpPost]
        [PermissionFilter(FunctionCode = FunctionCode.OrderVMS)]
        [ValidateAntiForgeryToken]
        public JsonResult OrderDelete(int id)
        {
            var ReturnData = new ReturnData();
            try
            {

                if (id > 0)
                {

                    var result = _oservice.Delete(id);
                    ReturnData.ResponseCode = result;
                    if (result >= 0)
                    {
                        ReturnData.Description = "Xóa đơn Thành Công";

                    }
                    else switch (result)
                        {
                            case -24: ReturnData.Description = "Chức năng đang trong trạng thái hoạt động. Hãy tắt trạng thái hoạt động của hệ thống trước khi xóa !"; break;
                            case -25: ReturnData.Description = "Chức năng không tồn tại trong hệ thống"; break;
                            case -99: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                            default: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                        }
                    return Json(ReturnData);
                }
                ReturnData.ResponseCode = -100;
                ReturnData.Description = "Không xác định chức năng cần xóa";
                return Json(ReturnData);
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau";
                return Json(ReturnData);
            }
        }
        [HttpPost]
        [PermissionFilter(FunctionCode = FunctionCode.OrderVMS)]
        [ValidateAntiForgeryToken]
        public JsonResult OrderUpdate(int id, string password, string extend)
        {
            var ReturnData = new ReturnData();
            try
            {

                if (id > 0)
                {
                    var orderObj = _oservice.Get(id);
                    if (!string.IsNullOrEmpty(password))
                    {
                        orderObj.Password = password;
                    }
                    if (!string.IsNullOrEmpty(extend))
                    {
                        orderObj.ExtData = extend;
                    }
                    var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                    if (string.IsNullOrEmpty(token))
                    {
                        token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                        Session[SessionsManager.SESSION_TOKEN] = token;
                    }
                    var parrentUser = _userservice.GetByUsername(CurrentFullUser.CreatedUser);
                    var C1User = parrentUser;
                    if (CurrentFullUser.Type == 5)
                        C1User = _userservice.GetByUsername(parrentUser.CreatedUser);

                    var pecent = 0;
                    var amount = orderObj.Amount;
                    var pecentParent = 0;
                    var pecentC1 = 0;
                    switch (orderObj.Telco)
                    {
                        case "VNP":
                            pecent = CurrentFullUser.PercentVNP;
                            pecentParent = parrentUser.PercentVNP;
                            pecentC1 = C1User.PercentVNP;
                            break;
                        case "VTT":
                            pecent = CurrentFullUser.PercentVTT;
                            pecentParent = parrentUser.PercentVTT;
                            pecentC1 = C1User.PercentVTT;
                            break;
                        case "ZING":
                            pecent = CurrentFullUser.PercentZing;
                            pecentParent = parrentUser.PercentZing;
                            pecentC1 = C1User.PercentZing;
                            break;
                        default:
                            pecent = CurrentFullUser.PercentVMS;
                            pecentParent = parrentUser.PercentVMS;
                            pecentC1 = C1User.PercentVMS;
                            break;
                    }
                    if (parrentUser.Type <= 2)
                        pecentParent = pecent;

                    if (parrentUser.Type <= 3)
                        pecentC1 = pecentParent;

                    if (pecentParent < pecentC1)
                        pecentParent = pecentC1;
                    if (pecent < pecentParent)
                        pecent = pecentParent;

                    amount = amount * pecent / 100;

                    //var data = ServerProcess.ListTransaction(token, 10000, "VMS", "", null, 0);
                    //if (data.Exists(x => x.Mobile.Equals(orderObj.Mobile)))
                    //{
                    //    ReturnData.ResponseCode = -105;
                    //    ReturnData.Description = "Số điện thoại đang tiến hành nạp. Vui lòng thêm đơn hàng khác";
                    //    return Json(ReturnData);
                    //}

                    var resultDeduct = _transervice.DeductHold(CurrentFullUser.Username, amount, "Trừ tiền tạo giao dịch " + orderObj.OrderNo);
                    if (resultDeduct < 0)
                    {
                        switch (resultDeduct)
                        {
                            case -98: ReturnData.Description = "Số dư tài khoản không đủ để thực hiện giao dịch"; break;
                            default: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                        }
                        return Json(ReturnData);

                    }

                    var resultapi = ServerProcess.OrderAdd(orderObj, token, CurrentFullUser, pecent, pecentParent, pecentC1);
                    if (resultapi <= 0)
                    {
                        //lỗi thì hoàn tiền
                        _transervice.TopupHold(CurrentFullUser.Username, amount, "Hoàn tiền tạo giao dịch " + orderObj.OrderNo);
                        ReturnData.ResponseCode = resultapi;
                        ReturnData.Description = String.Format("Hệ thống đang bận. Vui lòng quay lại sau ({0})", resultapi);
                        return Json(ReturnData);

                    }
                    _oservice.Delete(id);
                    _userlogservice.InsertUsersLog(new UsersLog
                    {
                        FunctionCode = "Orders",
                        Description = String.Format("Tạo giao dịch {0}-{1} số tiền trừ tạm :{2} chiết khấu :{3}", orderObj.OrderNo, resultapi, amount, 100 - pecent),
                        UserID = CurrentFullUser.UserID,
                        UserName = CurrentFullUser.Username,
                        LogType = pecent,
                        ClientIP = resultapi.ToString()
                    });
                    _userservice.SetDay(CurrentFullUser.UserID, CurrentFullUser.CreatedUser, amount);
                    ReturnData.ResponseCode = resultapi;
                    ReturnData.Description = "Thành công";
                    Session[SessionsManager.SESSION_USER_FULL] = null;
                    return Json(ReturnData);
                }
                ReturnData.ResponseCode = -100;
                ReturnData.Description = "Không xác định chức năng cần xóa";
                return Json(ReturnData);
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau";
                return Json(ReturnData);
            }
        }
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult GetToken(string Mobile, string Telco)
        {
            var ReturnData = new ReturnData();
            ReturnData.ResponseCode = -1;
            ReturnData.Description = "Không có dữ liệu";

            if (Telco == "VMS")
            {
                //var token = _accounttokenservice.Get(Mobile);
                //if (token != null)
                //{
                //    ReturnData.ResponseCode = 1;
                //    ReturnData.Description = token.Token;
                //    return Json(ReturnData);
                //}
                var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                if (string.IsNullOrEmpty(token))
                {
                    token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                    Session[SessionsManager.SESSION_TOKEN] = token;
                }
                ReturnData.ResponseCode = 1;
                ReturnData.Description = ServerProcess.GetTelco(Mobile, Telco.ToLower(), token);
                return Json(ReturnData);
            }


            return Json(ReturnData);
        }
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult SetToken(string Mobile, string Token)
        {
            var ReturnData = new ReturnData();
            ReturnData.ResponseCode = 1;
            var token = new AccountToken
            {
                Mobile = Mobile,
                Token = Token
            };
            _accounttokenservice.InsertUpdate(token);
            return Json(ReturnData);
        }
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult FormOrder(OrderModel order)
        {
            var ReturnData = new ReturnData();
            try
            {
                if (CurrentFullUser == null)
                {

                    ReturnData.ResponseCode = -101;
                    ReturnData.Description = "Bạn không có quyền sử dụng chức năng này";
                    return Json(ReturnData);

                }
                var password = Encrypt.MD5(order.Password2.Trim() + Config.GetAppsetting("Salt"));
                if (CurrentFullUser.Password2 != password)
                {
                    ReturnData.ResponseCode = -104;
                    ReturnData.Description = "Mật khẩu bán hàng không chính xác";
                    return Json(ReturnData);
                }
                Session["MKBH"] = order.Password2.Trim();
                var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                if (string.IsNullOrEmpty(token))
                {
                    token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                    Session[SessionsManager.SESSION_TOKEN] = token;
                }
                var parrentUser = _userservice.GetByUsername(CurrentFullUser.CreatedUser);
                var C1User = parrentUser;
                if (CurrentFullUser.Type == 5)
                    C1User = _userservice.GetByUsername(parrentUser.CreatedUser);
                var pecent = 0;
                var amount = order.Amount;
                var pecentParent = 0;
                var pecentC1 = 0;
                switch (order.Telco)
                {
                    case "VNP":
                        pecent = CurrentFullUser.PercentVNP;
                        pecentParent = parrentUser.PercentVNP;
                        pecentC1 = C1User.PercentVNP;
                        break;
                    case "VTT":
                        pecent = CurrentFullUser.PercentVTT;
                        pecentParent = parrentUser.PercentVTT;
                        pecentC1 = C1User.PercentVTT;
                        break;
                    case "Zing":
                        pecent = CurrentFullUser.PercentZing;
                        pecentParent = parrentUser.PercentZing;
                        pecentC1 = C1User.PercentZing;
                        break;
                    case "Garena":
                        pecent = CurrentFullUser.PercentGarena;
                        pecentParent = parrentUser.PercentGarena;
                        pecentC1 = C1User.PercentGarena;
                        //order.TopupType = "9";
                        break;
                    case "VTC":
                        pecent = CurrentFullUser.PercentVTC;
                        pecentParent = parrentUser.PercentVTC;
                        pecentC1 = C1User.PercentVTC;
                        //order.TopupType = "9";
                        break;
                    default:
                        pecent = CurrentFullUser.PercentVMS;
                        pecentParent = parrentUser.PercentVMS;
                        pecentC1 = C1User.PercentVMS;

                        break;
                }
                if (order.Telco == "VTT")
                {
                    //không my
                    //if (((order.TopupType == "1" || order.TopupType == "2") && string.IsNullOrEmpty(order.Password))|| order.Ussd >=1)
                    if ((order.TopupType == "2") && string.IsNullOrEmpty(order.Password))
                    {
                        order.Ussd = 2;
                        pecent += int.Parse(Config.GetAppsetting("P1Ussd"));
                        pecentParent += int.Parse(Config.GetAppsetting("P1Ussd"));
                        pecentC1 += int.Parse(Config.GetAppsetting("P1Ussd"));

                    }
                    if ((order.TopupType == "5"))
                    {
                        order.Ussd = 1;
                        //pecent += int.Parse(Config.GetAppsetting("P1Ussd"));
                        //pecentParent += int.Parse(Config.GetAppsetting("P1Ussd"));
                    }
                    //if (order.TopupType == "3")
                    //{
                    //    if (order.Ussd > 0)
                    //    {
                    //        order.Ussd = 1;

                    //    }
                    //}

                }
                else
                {
                    order.Ussd = 0;
                }
                //trả trước
                if (order.Telco == "VTT" && order.Ussd > 0 && order.TopupType == "1")
                {
                    order.Ussd = 0;
                }
                //trả sau mix
                if (order.Telco == "VTT" & order.TopupType == "2" && String.IsNullOrEmpty(order.Password))
                {
                    order.Ussd = 1;
                }
                //nạp hộ trả trước
                if (order.Telco == "VTT" && order.TopupType == "1" && String.IsNullOrEmpty(order.Password))
                {
                    return Json(ReturnData);
                }
                //cấp 1 tạo đơn
                if (parrentUser.Type <= 2)
                {
                    pecentParent = pecent;

                }
                if (parrentUser.Type <= 3)
                    pecentC1 = pecentParent;


                if (pecentParent < pecentC1)
                    pecentParent = pecentC1;
                if (pecent < pecentParent)
                    pecent = pecentParent;

                amount = amount * pecent / 100;

                if (order.Telco == "VMS")
                {
                    var data = ServerProcess.ListTransaction(token, 10000, "VMS", "", null, 0);
                    if (data.Exists(x => x.Mobile.Equals(order.Mobile)))
                    {
                        ReturnData.ResponseCode = -105;
                        ReturnData.Description = "Số điện thoại đang tiến hành nạp. Vui lòng thêm đơn hàng khác";
                        return Json(ReturnData);
                    }
                }
                //return Json(ReturnData);
                //tạo order
                var orderObj = new OrderInput
                {
                    AccountName = order.Mobile,
                    AmountMin = order.AmountMin,
                    AmountMinAll = order.AmountMinAll,
                    Amount = order.Amount,
                    FullName = order.FullName,
                    Mobile = order.Mobile,
                    //OrderNo = String.Format("{0}_{1}_{2}LE{3}", CurrentFullUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), order.Telco),
                    Password = order.Password,
                    Priority = CurrentFullUser.Piority,
                    Telco = order.Telco,
                    Ussd = order.Ussd,
                    TopupType = order.TopupType,


                };
                //if (orderObj.AmountMin == 0)
                //{
                //    orderObj.AmountMin = orderObj.AmountMinAll;
                //}
                if (string.IsNullOrEmpty(orderObj.FullName))
                {
                    orderObj.FullName = orderObj.Mobile;
                }
                orderObj.OrderNo = String.Format("{0}_{1}_{2}", CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), order.Telco);

                //order của cấp 2
                if (CurrentFullUser.Type == 4)
                {

                    orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}", parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), order.Telco);
                    orderObj.Priority = parrentUser.Piority;
                }
                //cấp 3
                if (CurrentFullUser.Type == 5)
                {

                    orderObj.OrderNo = String.Format("{0}_{1}_{2}_{3}_{4}", C1User.Config, parrentUser.Config, CurrentFullUser.Config, DateTime.Now.ToString("ddMMyy"), order.Telco);
                    orderObj.Priority = parrentUser.Piority;
                }
                var resultDeduct = _transervice.DeductHold(CurrentFullUser.Username, amount, "Trừ tiền tạo giao dịch " + orderObj.OrderNo);
                if (resultDeduct < 0)
                {
                    switch (resultDeduct)
                    {
                        case -98: ReturnData.Description = "Số dư tài khoản không đủ để thực hiện giao dịch"; break;
                        default: ReturnData.Description = "Số dư tài khoản không đủ để thực hiện giao dịch"; break;
                    }
                    return Json(ReturnData);

                }

                var resultapi = ServerProcess.OrderAdd(orderObj, token, CurrentFullUser, pecent, pecentParent, pecentC1);
                if (resultapi <= 0)
                {
                    //lỗi thì hoàn tiền
                    _transervice.TopupHold(CurrentFullUser.Username, amount, "Hoàn tiền tạo giao dịch " + orderObj.OrderNo);
                    ReturnData.ResponseCode = resultapi;
                    ReturnData.Description = String.Format("Hệ thống đang bận. Vui lòng quay lại sau ({0})", resultapi);
                    return Json(ReturnData);

                }

                _userlogservice.InsertUsersLog(new UsersLog
                {
                    FunctionCode = "Orders",
                    Description = String.Format("Tạo giao dịch {0}-{1} số tiền trừ tạm :{2} chiết khấu :{3}", orderObj.OrderNo, resultapi, amount, 100 - pecent),
                    UserID = CurrentFullUser.UserID,
                    UserName = CurrentFullUser.Username,
                    LogType = pecent,
                    ClientIP = resultapi.ToString()
                });
                //_userservice.SetDay(CurrentFullUser.UserID, CurrentFullUser.CreatedUser, amount);
                ReturnData.ResponseCode = resultapi;
                ReturnData.Description = "Thành công";
                Session[SessionsManager.SESSION_USER_FULL] = null;
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Có lỗi trong quá trình xử lý";
            }

            return Json(ReturnData);

        }
        public ActionResult BidHistory(long id)
        {
            var order = _bidHistoryservice.GetListBidHistory(0, id);
            ViewBag.id = id;
            return PartialView(order);
        }
        public ActionResult OrderBidMulti(string Order)
        {

            var token = Session[SessionsManager.SESSION_TOKEN].ToString();
            if (string.IsNullOrEmpty(token))
            {
                token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                Session[SessionsManager.SESSION_TOKEN] = token;
            }
            var data = ServerProcess.ListTransaction(token, 10000, "", Order, null, 0);
            if (data.FirstOrDefault().SubUser != CurrentFullUser.Username)
                return new EmptyResult();
            ViewBag.Order = Order;
            decimal maxBidRate = 0;
            int amount = 0;

            foreach (var obj in data)
            {
                if ((obj.Status == 2 || obj.Status == 1 || obj.Status == -3) && (obj.IsConfirm != 1) && obj.AmountTopupSuccess < obj.Amount)
                {
                    if (maxBidRate < obj.BidRate)
                        maxBidRate = obj.BidRate.GetValueOrDefault();
                    amount += (obj.Amount - obj.AmountTopupSuccess);
                }
            }
            ViewBag.maxBidRate = maxBidRate;
            ViewBag.amount = amount;
            ViewBag.max = 40;
            if (data.FirstOrDefault().Telco == "vtt" || data.FirstOrDefault().Telco == "vnp" || data.FirstOrDefault().Telco == "vms")
                ViewBag.max = 30;
            return PartialView();
        }
        public ActionResult OrderBid(long id)
        {
            var order = _orderservice.Get(id);
            if (order.UserName != CurrentFullUser.Username)
                return new EmptyResult();
            ViewBag.id = id;
            ViewBag.max = 40;
            if (order.Telco == "vtt" || order.Telco == "vnp" || order.Telco == "vms")
                ViewBag.max = 30;
            return PartialView(order);
        }
        public ActionResult TopBid()
        {
            var request = System.Web.HttpContext.Current.Request;
            var mobileHelper = new MobileDetectHelper(request);

            ViewBag.IsMobile = mobileHelper.DetectMobileLong();
            return PartialView();
        }
        public ActionResult ListTopBid(string Telco, int? BidRate, int? AmountMin, int type = 1)
        {
            var data = _orderservice.GetTopBid(50000, "", Telco, BidRate.GetValueOrDefault());
            if (AmountMin.GetValueOrDefault() > 0)
                data = data.Where(x => (x.Amount - x.AmoutSuccess) >= AmountMin.GetValueOrDefault()).ToList();

            var lstData = new List<OrderReport>();
            var lstRate = data.GroupBy(x => x.BidRate).Select(a => a.Key).ToList();
            var lstOrder = data.GroupBy(x => x.OrderNo).Select(a => a.Key).ToList();
            foreach (var rate in lstRate)
            {
                foreach (var Order in lstOrder)
                {
                    if (data.Exists(x => x.BidRate == rate && x.OrderNo == Order))
                    {
                        var item = new OrderReport
                        {
                            BidRate = rate,
                            OrderNo = Order,
                            UserApi = data.FirstOrDefault(x => x.BidRate == rate && x.OrderNo == Order).UserApi,
                            Amount = data.Where(x => x.BidRate == rate && x.OrderNo == Order).Sum(x => x.Amount),
                            AmoutSuccess = data.Where(x => x.BidRate == rate && x.OrderNo == Order).Sum(x => x.AmoutSuccess)

                        };
                        lstData.Add(item);
                    }
                }

            }
            ViewBag.UserType = CurrentUser.Type;
            return PartialView(lstData);


        }

        public ActionResult ListGroupBid(string Telco, int? BidRate, int? AmountMin)
        {
            var data = _orderservice.GetGroupBid(50000, "", Telco, AmountMin.GetValueOrDefault());

            ViewBag.UserType = CurrentUser.Type;
            ViewBag.Total = data.Sum(x => x.TotalAmount / 100) - data.Sum(x => x.TotalAmountSuccess / 100);

            var Hour = DateTime.Now.Hour - 1;
            ViewBag.CountVTT = ServerProcess.GetCountCard("VTT", Hour);
            ViewBag.CountVMS = ServerProcess.GetCountCard("VMS", Hour);
            ViewBag.CountVNP = ServerProcess.GetCountCard("VNP", Hour);
            ViewBag.CountZing = ServerProcess.GetCountCard("Zing", Hour);
            ViewBag.CountGarena = ServerProcess.GetCountCard("Garena", Hour);
            var Warning = "";
            var token = Session[SessionsManager.SESSION_TOKEN].ToString();
            if (string.IsNullOrEmpty(token))
            {
                token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                Session[SessionsManager.SESSION_TOKEN] = token;
            }
            var lstOrder = ServerProcess.CountWaitingCache(token);
            if (lstOrder.Exists(x => x.Telco == "vtt"))
            {
                if (lstOrder.FirstOrDefault(x => x.Telco == "vtt").TotalAmount < 50000000)
                    Warning += "Sản lượng Viettel đang tăng. Vui lòng tạo đơn";
            }

            ViewBag.Warning = Warning;
            return PartialView(data);
        }
        [ValidateAntiForgeryToken]
        [HttpPost]

        public JsonResult OrderBid(long id, decimal bidRate)
        {
            var ReturnData = new ReturnData();
            try
            {


                if (id > 1)
                {
                    ReturnData.ResponseCode = 1;
                    var order = _orderservice.Get(id);
                    if (bidRate > 40)
                    {
                        ReturnData.ResponseCode = -103;
                        ReturnData.Description = "Dữ liệu đầu vào không hợp lệ";
                        return Json(ReturnData);
                    }
                    if (order.BidRate != bidRate)
                    {
                        //giam gia
                        if (order.BidRate > bidRate)
                        {
                            if (ServerProcess.GetBidCache(order.OrderId.ToString()) > 0)
                            {
                                ReturnData.ResponseCode = -103;
                                ReturnData.Description = "Giao dịch đang xử lí, vui lòng quay lại sau 5 phút";
                                return Json(ReturnData);
                            }
                        }

                        //trừ tạm transaction( trừ hoặc cộng)
                        int BidFee = (order.Amount - order.AmoutSuccess) / 100 * (int)bidRate;
                        var result = 0;

                        //tăng giá đua trừ tạm luôn
                        if (order.BidFeeHold < BidFee)
                        {
                            result = _transervice.DeductHold(CurrentFullUser.Username, BidFee - order.BidFeeHold, String.Format("Trừ tiền do điều chỉnh chiết khấu đua giá từ {0} thành {1}, đơn {2}-{3}, chi phí đua giá {4}", (int)order.BidRate, (int)bidRate, order.OrderNo, order.OrderId, BidFee), id.ToString());
                        }
                        if (result < 0)
                        {
                            ReturnData.Description = "Tài khoản của bạn không đủ số dư";
                            ReturnData.ResponseCode = -1;
                            return Json(ReturnData);
                        }

                        //update rate ở core
                        var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                        if (string.IsNullOrEmpty(token))
                        {
                            token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                            Session[SessionsManager.SESSION_TOKEN] = token;
                        }
                        var orderApi = ServerProcess.GetOrder(token, id);
                        orderApi.BidRate = bidRate;
                        int Priority = 1;

                        orderApi.Priority = Priority + 40 - (int)bidRate;
                        if (orderApi.Priority < 1) orderApi.Priority = 1;

                        if (ServerProcess.OrderUpdateBid(orderApi, token) >= 0)
                        {
                            _orderservice.UpdateBid(order.OrderId, bidRate, BidFee);
                            //giảm giá đua hoàn lại tiền
                            if (order.BidFeeHold > BidFee)
                            {
                                result = _transervice.TopupHold(CurrentFullUser.Username, order.BidFeeHold - BidFee, String.Format("Hoàn tiền do điều chỉnh chiết khấu đua giá từ {0} thành {1}, đơn {2}-{3}, chi phí đua giá {4}", (int)order.BidRate, (int)bidRate, order.OrderNo, order.OrderId, BidFee), id.ToString());
                            }

                            //ghi log đua giá
                            var logBid = new BidHistory
                            {
                                OrderId = order.OrderId,
                                OrderNo = order.OrderNo,
                                UserID = CurrentFullUser.UserID,
                                Description = String.Format("Điều chỉnh chiết khấu đua giá từ {0} thành {1}, chi phí đua giá {2}", (int)order.BidRate, (int)bidRate, BidFee)
                            };
                            _bidHistoryservice.InsertBidHistory(logBid);
                            if (ReturnData.ResponseCode >= 0)
                            {
                                ServerProcess.SetBidCache(id.ToString());
                                Session[SessionsManager.SESSION_USER_FULL] = null;
                                ReturnData.Description = "Giao dịch Thành Công";
                                return Json(ReturnData);
                            }
                            else switch (ReturnData.ResponseCode)
                                {
                                    case -50: ReturnData.Description = "Tài Khoản không tồn tại"; break;
                                    case -98: ReturnData.Description = "Số dư không đủ để thực hiện giao dịch"; break;
                                    case -99: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                                    case -101: ReturnData.Description = "Không có quyền thực hiện chức năng này"; break;
                                    default: ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau"; break;
                                }
                            return Json(ReturnData);
                        }
                        else
                        {
                            //hoàn tiền trừ tạm trước
                            if (order.BidFeeHold < BidFee)
                            {
                                result = _transervice.TopupHold(CurrentFullUser.Username, BidFee - order.BidFeeHold, String.Format("Hoàn tiền do điều chỉnh chiết khấu đua giá từ {0} thành {1} thất bại, đơn {2}-{3}, chi phí đua giá {4}", (int)order.BidRate, (int)bidRate, order.OrderNo, order.OrderId, BidFee), id.ToString());
                            }
                            ReturnData.ResponseCode = -103;
                            ReturnData.Description = "Giao dịch đang xử lí, vui lòng quay lại sau 5 phút";
                            return Json(ReturnData);
                        }



                    }
                    else
                    {
                        ReturnData.Description = "Bạn cần cập nhật chiết khấu đua giá";
                        ReturnData.ResponseCode = -1;
                        return Json(ReturnData);
                    }


                }
                ReturnData.ResponseCode = -100;
                ReturnData.Description = "Không xác định user cần active";
                return Json(ReturnData);
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau";
                return Json(ReturnData);
            }
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public JsonResult OrderBidMulti(string OrderNo, decimal bidRate)
        {
            var ReturnData = new ReturnData();
            if (bidRate > 40)
            {
                ReturnData.ResponseCode = -103;
                ReturnData.Description = "Dữ liệu đầu vào không hợp lệ";
                return Json(ReturnData);
            }
            try
            {

                var token = Session[SessionsManager.SESSION_TOKEN].ToString();
                if (string.IsNullOrEmpty(token))
                {
                    token = ServerProcess.GetUserTokenCache(CurrentFullUser.UserAPI, CurrentFullUser.PasswordAPI);
                    Session[SessionsManager.SESSION_TOKEN] = token;
                }
                int Priority = 1;


                var data = ServerProcess.ListTransaction(token, 10000, "", OrderNo, 1, 0);
                data = data.Where(x => x.Status == 1).ToList();

                //giảm giá
                decimal maxBidRate = data.Max(x => x.BidRate.GetValueOrDefault());
                if (maxBidRate > bidRate)
                {
                    if (ServerProcess.GetBidCache(OrderNo) > 0)
                    {
                        ReturnData.ResponseCode = -103;
                        ReturnData.Description = "Giao dịch đang xử lí, vui lòng quay lại sau 5 phút";
                        return Json(ReturnData);
                    }
                }
                foreach (var orderApi in data)
                {
                    ReturnData.ResponseCode = 1;
                    var order = _orderservice.Get(orderApi.TransactionID);

                    if (order.BidRate != bidRate)
                    {
                        //trừ tạm transaction( trừ hoặc cộng)
                        int BidFee = (order.Amount - order.AmoutSuccess) / 100 * (int)bidRate;
                        var result = 0;

                        //tăng giá đua
                        if (order.BidFeeHold < BidFee)
                        {
                            result = _transervice.DeductHold(CurrentFullUser.Username, BidFee - order.BidFeeHold, String.Format("Trừ tiền do điều chỉnh chiết khấu đua giá từ {0} thành {1}, đơn {2}-{3}, chi phí đua giá {4}", (int)order.BidRate, (int)bidRate, order.OrderNo, order.OrderId, BidFee));
                        }
                        if (result < 0)
                        {
                            NLogLogger.Info(String.Format("{0} {1}", result, BidFee - order.BidFeeHold));
                            ReturnData.Description = "Tài khoản của bạn không đủ số dư";
                            ReturnData.ResponseCode = -1;
                            return Json(ReturnData);
                        }


                        //update rate ở core
                        orderApi.BidRate = bidRate;
                        orderApi.Priority = Priority + 40 - (int)bidRate;
                        if (orderApi.Priority < 1) orderApi.Priority = 1;

                        if (ServerProcess.OrderUpdateBid(orderApi, token) >= 0)
                        {
                            //giảm giá đua
                            if (order.BidFeeHold > BidFee)
                            {
                                result = _transervice.TopupHold(CurrentFullUser.Username, order.BidFeeHold - BidFee, String.Format("Hoàn tiền do điều chỉnh chiết khấu đua giá từ {0} thành {1}, đơn {2}-{3}, chi phí đua giá {4}", (int)order.BidRate, (int)bidRate, order.OrderNo, order.OrderId, BidFee));
                            }

                            _orderservice.UpdateBid(order.OrderId, bidRate, BidFee);

                            ServerProcess.SetBidCache(order.OrderId.ToString());
                            //ghi log đua giá
                            var logBid = new BidHistory
                            {
                                OrderId = order.OrderId,
                                OrderNo = order.OrderNo,
                                UserID = CurrentFullUser.UserID,
                                Description = String.Format("Điều chỉnh chiết khấu đua giá từ {0} thành {1}, chi phí đua giá {2}", (int)order.BidRate, (int)bidRate, BidFee)
                            };
                            _bidHistoryservice.InsertBidHistory(logBid);
                        }
                        else
                        {
                            //tăng giá đua
                            if (order.BidFeeHold < BidFee)
                            {
                                result = _transervice.TopupHold(CurrentFullUser.Username, BidFee - order.BidFeeHold, String.Format("Hoàn tiền do điều chỉnh chiết khấu đua giá từ {0} thành {1} thất bại, đơn {2}-{3}, chi phí đua giá {4}", (int)order.BidRate, (int)bidRate, order.OrderNo, order.OrderId, BidFee));
                            }
                        }


                    }


                }

                if (ReturnData.ResponseCode >= 0)
                {
                    ServerProcess.SetBidCache(OrderNo);
                    Session[SessionsManager.SESSION_USER_FULL] = null;
                    ReturnData.Description = "Giao dịch Thành Công";
                    return Json(ReturnData);
                }


                ReturnData.ResponseCode = -100;
                ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau";
                return Json(ReturnData);
            }
            catch (Exception ex)
            {
                NLogLogger.PublishException(ex);
                ReturnData.ResponseCode = -99;
                ReturnData.Description = "Hệ thống đang bận. Vui lòng quay lại sau";
                return Json(ReturnData);
            }
        }
        public ActionResult AddOrder(string Order, string Telco)
        {

            if (CurrentUser == null)
                return RedirectToAction("Login", "Account");
            var user = _userservice.GetByUsername(CurrentUser.Username);
            if (!user.StatusVTT)
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.MKBH = "";
            if (Session["MKBH"] != null)
            {
                ViewBag.MKBH = Session["MKBH"].ToString();
            }
            ViewBag.Order = Order;
            ViewBag.Telco = Telco;
            Session[SessionsManager.SESSION_USER_FULL] = user;
            return PartialView(user);
        }
    }

}